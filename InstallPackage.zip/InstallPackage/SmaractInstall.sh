#!/bin/bash
FOLDER=$(realpath $(dirname $0))
if ! mkdir -p "${FOLDER}/build"; then
    echo "Error, cannot create 'build' folder in '${FOLDER}'."
    exit 2
fi
pushd "${FOLDER}/build"
mcscontrol="${FOLDER}/libmcscontrol.tgz"
if [ ! -e $mcscontrol ]; then
    echo "You need to copy the file libmcscontrol-*.tgz as libmcscontrol.tgz in this folder."
    echo "This file can be obtained from the manufacturer of your actuator."
    exit 1
fi
tar zxvf "${mcscontrol}"
if [ $? -ne 0 ]; then
    echo "Error: cannot uncompress file '${mcscontrol}'"
    exit 2
fi
pushd libmcscontrol
sudo ./install /usr/local
if [ $? -ne 0 ]; then
    popd
    popd
    echo "Failed to install mcscontrol"
    return 2
fi
popd
popd
sudo cp "${FOLDER}/blacklist-extensometer.conf" /etc/modprobe.d/ &&
    sudo ldconfig
