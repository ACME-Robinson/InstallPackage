/* 
 * File:   SmarActRobot.hpp
 * Author: huflejt
 *
 * Created on November 5, 2012, 6:11 PM
 */

#ifndef SMARACTACTUATORSYSTEM_HPP
#define	SMARACTACTUATORSYSTEM_HPP

//#include "ZaberCommander.h"
//#include "ActuatorSystem.hpp"
//#include "SmarActCommander.hpp"//not needed
//#include "SmarActActuatorAxis.hpp"
//#include "MeasurementState.hpp"
//#include "StateManager.hpp"
//#include <exception>
//#include "QMap"

//class SmarActActuatorSystem : public ActuatorSystem{
//public:
//    explicit SmarActActuatorSystem(unsigned int systemID, unsigned int localSystemID);
    //SmarActRobot(const SmarActRobot& orig);
//    virtual ~SmarActActuatorSystem();
   // bool Init(int acceleration);        
   // bool GetPosition(int axis, int& position);
   // bool UpdateRobotState();        
  //  bool InitSystem();
  //  bool UpdateRobotState(int axis);
    //bool GotoPositionAbsolute(int axis, int position);
    //bool GotoPosition(int axis, int targetPosition);//TODO: this is wrong
    //bool Goto(int axisID, double positionMicrons);
//    int errorCount()
//	{
//		return _errorCount;
//	};

//private:
//protected:
    //QMap<SA_STATUS, QString> StatusMap;
    //static QMap<SA_STATUS, QString> InitializeStatusMap();
    //SmarActCommander commander;
//    double microstepSize;        
//    int _fieldIdPositionMicrons0;
//    int _fieldIdPositionMicrons1;
//    int _fieldIdPositionMicrons2;
//    int _fieldIdCrystalState0;
//    int _fieldIdCrystalState1;
//    int _fieldIdCrystalState2;
//    int _errorCount;
//};




#endif	/* SMARACTROBOT_HPP */

