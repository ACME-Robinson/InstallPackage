/* 
 * File:   Sensor.cpp
 * Author: acme
 * 
 * Created on March 1, 2013, 4:09 PM
 */

#include "Sensor.hpp"

Sensor::Sensor(HardwareController* hardwareController): RobotSubunit(hardwareController) {        
}


Sensor::~Sensor() {
}

