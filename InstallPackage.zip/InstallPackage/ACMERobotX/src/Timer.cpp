/* 
 * File:   Timer.cpp
 * Author: huflejt
 * 
 * Created on November 19, 2012, 6:16 PM
 */

#include "Timer.hpp"

Timer::Timer() {
    Reset();
}

Timer::~Timer() {
}



