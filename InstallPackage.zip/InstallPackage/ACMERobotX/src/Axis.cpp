/* 
 * File:   Axis.cpp
 * Author: acme
 * 
 * Created on March 1, 2013, 4:09 PM
 */

#include <qt4/QtCore/qstring.h>

#include "Axis.hpp"
#include "parms.hpp"
#include "HardwareController.hpp"
    

Axis::Axis(HardwareController* hardwareController): RobotSubunit(hardwareController) {    
   
}

Axis::~Axis() {
}



