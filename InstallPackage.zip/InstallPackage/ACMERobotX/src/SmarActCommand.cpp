/* 
 * File:   SmarActCommand.cpp
 * Author: acme
 * 
 * Created on February 12, 2013, 6:07 PM
 */

#include "SmarActCommand.hpp"

SmarActCommand::SmarActCommand() {
}

SmarActCommand::~SmarActCommand() {
}

