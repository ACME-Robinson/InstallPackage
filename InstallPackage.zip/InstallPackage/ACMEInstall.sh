#!/bin/bash
FOLDER=$(realpath $(dirname $0))
BUILD_FOLDER=$(realpath $(dirname $0))/build

compileCMake() {
    cmake "$@"
    make
}

installACMERobotX() {
    echo "*****************************"
    echo "*** Installing ACMERobotX ***"
    echo "*****************************"
    rm -Rf "${BUILD_FOLDER}/ACMERobotX" &&
    mkdir  -p "${BUILD_FOLDER}/ACMERobotX" &&
    pushd "${BUILD_FOLDER}/ACMERobotX" &&
    compileCMake "${FOLDER}/ACMERobotX"

    if [ $? -ne 0 ]; then
        popd
        echo "Error, cannot compile ACMERobotX"
        return 2
    fi

    sudo make install &&
    sudo ldconfig
    if [ $? -ne 0 ]; then
        popd
        echo "Error, cannot install ACMERobotX"
        return 2
    fi
    popd
    echo DONE
    echo
}

installACME() {
    echo "***********************"
    echo "*** Installing ACME ***"
    echo "***********************"
    rm -Rf "${BUILD_FOLDER}/ACME" &&
    mkdir -p "${BUILD_FOLDER}/ACME" &&
    pushd "${BUILD_FOLDER}/ACME" &&
    compileCMake -DCMAKE_INSTALL_PREFIX="${FOLDER}" "${FOLDER}/ACME"
    if [ $? -ne 0 ]; then
        popd
        echo "Error, cannot compile ACME."
        return 2
    fi
    if ! make install; then
        popd
        echo "Error, cannot install ACME"
        return 2
    fi
    popd
    echo DONE
    echo
}

installACMETracker() {
    echo "******************************"
    echo "*** Installing ACMETracker ***"
    echo "******************************"
    # install flyCapture
    dist=$(lsb_release -s -c)
    flycapture="${FOLDER}/FlyCapture2/${dist}-$(uname -m)"
    if [ -d "$flycapture" ]; then
        pushd "$flycapture"
        ./install_flycapture.sh &&
            sudo apt-get -f install
        if [ $? -ne 0 ]; then
            echo "Warning: failed to install flycapture2 from ${flycapture}. Check archive integrity."
            echo "ACMETracker won't have access to the flycapture2 module."
        fi
        popd
    else
        echo "Warning, no FlyCapture2 software for your distribution (codename '$dist') in folder FlyCapture2."
        echo "Check https://www.ptgrey.com/support/downloads to see if there is one for you."
        echo "Your full distribution name is: $(lsb_release -s -d)"
    fi
    pushd "${FOLDER}/ACMETracker" &&
    python setup.py build
    if [ $? -ne 0 ]; then
        popd
        echo "Error building ACMETracker module"
        return 2
    fi

    if ! sudo python setup.py install; then
        popd
        echo "Error installing ACMETracker"
        return 2
    fi
    popd
    echo DONE
    echo
}

mkdir -p "${BUILD_FOLDER}" &&
installACMERobotX &&
installACME &&
installACMETracker
