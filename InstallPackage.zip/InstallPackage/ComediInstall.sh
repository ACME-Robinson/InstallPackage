#!/bin/bash

FOLDER=$(realpath $(dirname $0))/comedi

downloadAll() {
    echo "***********************************"
    echo "*** Downloading comedi software ***"
    echo "***********************************"
    rm -rf "${FOLDER}"
    mkdir -p "${FOLDER}"
    pushd "${FOLDER}"

    git clone git://comedi.org/git/comedi/comedi.git &&
        git clone git://comedi.org/git/comedi/comedilib.git &&
        git clone git://comedi.org/git/comedi/comedi_calibrate.git &&
        git clone git://comedi.org/git/comedi/comedi-nonfree-firmware.git

    if [ $? -ne 0 ]; then
        popd
        echo "Error, couldn't download all comedi software"
        return 2
    fi
    popd
    echo "DONE!"
    echo
}

installComedi() {
    echo "*************************"
    echo "*** Installing comedi ***"
    echo "*************************"
    pushd "${FOLDER}/comedi"

    ./autogen.sh &&
        autoconf &&
        ./configure &&
        make

    if [ $? -ne 0 ]; then
        popd
        echo "Error, couldn't compile comedi"
        return 2
    fi

    sudo make install &&
        sudo depmod -a

    if [ $? -ne 0 ]; then
        popd
        echo "Error, couldn't install comedi"
        return 2
    fi
    popd
    echo "DONE!"
    echo
}

installComediLib() {
    echo "****************************"
    echo "*** Installing comedilib ***"
    echo "****************************"
    pushd "${FOLDER}/comedilib"

    ./autogen.sh &&
        ./configure &&
        make

    if [ $? -ne 0 ]; then
        popd
        echo "Error, cannot compile comedilib"
        return 2
    fi

    if ! sudo make install; then
        popd
        echo "Error, couldn't install comedilib"
        return 2
    fi
    popd
    echo "DONE!"
    echo
}

installComediCalibrate() {
    echo "***********************************"
    echo "*** Installing comedi_calibrate ***"
    echo "***********************************"
    pushd "${FOLDER}/comedi_calibrate"

    ./autogen.sh &&
        ./configure &&
        make

    if [ $? -ne 0 ]; then
        popd
        echo "Error, cannot compile comedi_calibrate"
        return 2
    fi

    sudo make install &&
        sudo /sbin/modprobe ni_pcimio &&
        sudo comedi_config /dev/comedi0 ni_pcimio

    if [ $? -ne 0 ]; then
        popd
        echo "Error, couldn't install comedi_calibrate"
        return 2
    fi
    popd
    echo "DONE!"
    echo
}

installRules() {
    echo "************************"
    echo "*** Installing rules ***"
    echo "************************"
    sudo cp ${FOLDER}/../99-extensometer.rules /etc/udev/rules.d/ &&
        sudo ldconfig
}

downloadAll &&
    installComedi &&
    installComediLib &&
    installComediCalibrate &&
    installRules
