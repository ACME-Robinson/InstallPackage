/* 
 * File:   StiffnessMonitor.cpp
 * Author: acme
 * 
 * Created on March 26, 2013, 7:05 PM
 */

#include "StiffnessMonitor.hpp"

StiffnessMonitor::StiffnessMonitor(unsigned int maxElem, bool pushingIsPositive)
{
    this->maxElem = maxElem;
    this->pushingIsPositive = pushingIsPositive;
}

/*StiffnessMonitor::StiffnessMonitor(const StiffnessMonitor& orig) {
}*/

StiffnessMonitor::~StiffnessMonitor() {
}

