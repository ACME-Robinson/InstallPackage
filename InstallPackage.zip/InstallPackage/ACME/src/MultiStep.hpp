/*
 * File:   MultiCreepSkip.hpp
 * Author: acme
 *
 * Created on June 14, 2013, 3:08 PM
 */

#ifndef MULTISTEP_HPP
#define MULTISTEP_HPP

#include "Experiment.hpp"
#include "QString"

struct step
{
    QString type;
    double value;
    double duration;
};

class MultiStep : public Protocol{
public:
    const double double_nan = std::numeric_limits<double>::quiet_NaN();
    MultiStep(Experiment& experiment, QString sectionName);
    virtual ~MultiStep();

    virtual bool run();
    virtual bool Init(const Parms& parms);
    virtual bool writeParameters(Parms& parms) const;

protected:
    bool StepOpen(Axis* measurementAxis, double stepAbsMicrons, bool isClosingPositive);
    bool StepClose(Axis* measurementAxis, double stepAbsMicrons, bool isClosingPositive);
    bool CloseUntilStiffness(Axis* measurementAxis, ForceSensor* forceSensor, bool isClosingPositive);
    bool OpenUntilNoStiffness(Axis* measurementAxis, ForceSensor* forceSensor, bool isClosingPositive);
    bool WriteCalibration(double sensorOffsetVoltage, double zeroPosition);
    bool ReadLastCalibration(double &sensorOffsetVoltage, double &zeroPosition);

    enum ProtocolFlag{
        TareSensor=0,
        GoingToTargetForce1=1,
        Holding1=2,
        GoingToTargetForce2=3,
        Holding2=4,
        GoingToTargetPosition1=5,
        HoldingTargetPosition1=6,
        PreRelaxing=10,
        AdjustingJaws=100,
        ZeroPosition=101
    };

    bool Regulate(Axis* measurementAxis, ForceSensor* forceSensor,
                  bool isClosingPositive, double targetForceMicronewtons,
                  double timeoutSeconds, ProtocolFlag flagGoingTo, ProtocolFlag
                  flagHolding, double maxForceMicronewtons);
    bool KeepPosition(Axis* measurementAxis, ForceSensor* forceSensor,
                      bool isClosingPositive, double relativePositionMicrons,
                      double timeoutSeconds, ProtocolFlag flagGoingTo, ProtocolFlag
                      flagHolding, double maxForceMicronewtons);
    void UpdateProtocolFlag(ProtocolFlag flag)
    {
        experiment().stateManager().state().Update(_fieldIdProtocolFlag, flag);
    }

    void UpdateSequenceStep(int stepId)
    {
        experiment().stateManager().state().Update(_fieldIdSequenceStep, stepId);
    }

    int _fieldIdProtocolFlag = 0;
    int _fieldIdTime = 0;
    int _fieldIdSequenceStep = 0;

    double _stretchStepMicrons = -1;
    double _calibrationStepMicrons = -1; //step size for closing the extensometer jaws to find zero position
    double _maxTravelMicrons = -1;
    double _maxForceAbsMicronewtons = -1;
    double _forceMarginMicronewtons = -1;
    double _slowApproachFactor = -1;
    double _stiffnessThreshold = -1;
    double _defaultJawOpeningMicrons = -1;
    double _zeroPosition = -1;
    double _globalInitialPosition = -1;
    double _keepPositionToleranceMicrons = -1;

    bool _findZeroPosition = false;
    QString _calibrationFilename;
    std::vector<step> _steps;
    bool _observeRefForce = false;
    bool _ignoreUserInput = false; //useful for automated tests
};

#endif	/* MULTISTEP_HPP */

