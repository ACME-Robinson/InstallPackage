﻿1 - uncompress the archive somewhere
2 - from the uncompressed folder, type:
	sudo apt-get install pyqt4-dev-tools python-pip
	sudo pip install future==0.15
	sudo python setup.py install

then, it's ready to use!


To Use:

1. open terminal in folder with images
2. acme_tracker 'PATH TO params.ini file'  included in the image folder
3. select the plus and draw a box over the regions of interests. The selection should be on the tissue in a clear area and be reasonably large.(see ACMEhelpimage)
4. press play button to run
5. if the tracking does not work exit and try again selecting different regions or different sized regions. It depends on how much the region deforms between frames. 
6. The output is stored as a tracking.csv file where the images are.
